import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    home: ProfilePage(),
  ));
}

class ProfilePage extends StatefulWidget {
  const ProfilePage({Key? key}) : super(key: key);

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  bool _isLoggedIn = false;
  String _username = "";
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  Map<String, String> _userDatabase = {}; // Mock user database



  void _navigateToAboutApp() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => AboutAppPage()),
    );
  }

  Future<void> _showLoginDialog() async {
    return showDialog<void>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Login'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              TextField(
                controller: _usernameController,
                decoration: InputDecoration(labelText: 'Username'),
              ),
              TextField(
                controller: _passwordController,
                decoration: InputDecoration(labelText: 'Password'),
                obscureText: true,
              ),
            ],
          ),
          actions: <Widget>[
            TextButton(
              child: Text('Cancel'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
            TextButton(
              child: Text('Login'),
              onPressed: () async {
                final username = _usernameController.text;
                final password = _passwordController.text;
                final success = await _authenticate(username, password);

                if (success) {
                  setState(() {
                    _username = username;
                    _isLoggedIn = true;
                  });
                  Navigator.of(context).pop();
                  print("User $_username logged in");
                } else {
                  Navigator.of(context).pop();
                  _showErrorDialog('Login Failed', 'Invalid username or password.');
                }
              },
            ),
          ],
        );
      },
    );
  }

  Future<void> _showSignupDialog() async {
    return showDialog<void>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Sign Up'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              TextField(
                controller: _usernameController,
                decoration: InputDecoration(labelText: 'Username'),
              ),
              TextField(
                controller: _passwordController,
                decoration: InputDecoration(labelText: 'Password'),
                obscureText: true,
              ),
            ],
          ),
          actions: <Widget>[
            TextButton(
              child: Text('Cancel'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
            TextButton(
              child: Text('Sign Up'),
              onPressed: () {
                final username = _usernameController.text;
                final password = _passwordController.text;
                if (_userDatabase.containsKey(username)) {
                  Navigator.of(context).pop();
                  _showErrorDialog('Sign Up Failed', 'Username already exists.');
                } else {
                  _userDatabase[username] = password;
                  Navigator.of(context).pop();
                  _showSuccessDialog('Sign Up Successful', 'You can now log in with your credentials.');
                }
              },
            ),
          ],
        );
      },
    );
  }

  Future<void> _showErrorDialog(String title, String message) async {
    return showDialog<void>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(title),
          content: Text(message),
          actions: <Widget>[
            TextButton(
              child: Text('OK'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

  Future<void> _showSuccessDialog(String title, String message) async {
    return showDialog<void>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(title),
          content: Text(message),
          actions: <Widget>[
            TextButton(
              child: Text('OK'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

  Future<bool> _authenticate(String username, String password) async {
    await Future.delayed(Duration(seconds: 1));


    if (_userDatabase.containsKey(username) && _userDatabase[username] == password) {
      return true;
    } else {
      return false;
    }
  }

  void _login() {
    _showLoginDialog();
  }

  void _signup() {
    _showSignupDialog();
  }

  void _logout() {
    setState(() {
      _isLoggedIn = false;
      _username = "";
    });
    print("User logged out");
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ListView(
        padding: EdgeInsets.fromLTRB(15, 50, 15, 20),
        children: [
          CircleAvatar(
            radius: 150,
            backgroundColor: Colors.purpleAccent,
            backgroundImage: NetworkImage(
                'https://cdn2.iconfinder.com/data/icons/avatars-60/5985/12-Delivery_Man-512.png'),
          ),
          Padding(
            padding: EdgeInsets.only(top: 25, bottom: 10),
            child: const Center(
              child: Text(
                "Habit Tracker",
                style: TextStyle(
                    color: Colors.black,
                    fontSize: 22,
                    fontWeight: FontWeight.bold),
              ),
            ),
          ),
          Center(
            child: Text(
              "What a wonderful day!!",
              style: TextStyle(
                  color: Colors.black,
                  fontSize: 16,
                  fontWeight: FontWeight.w400),
            ),
          ),
          Padding(
            padding: EdgeInsets.all(10),
            child: Divider(),
          ),


          ListTile(
            leading: Icon(Icons.info),
            title: Text("About This App"),
            trailing: Icon(Icons.arrow_forward_ios),
            onTap: _navigateToAboutApp,
          ),
          Divider(),
          Center(
            child: _isLoggedIn
                ? Column(
              children: [
                Text(
                  'Welcome, $_username!',
                  style: TextStyle(
                      color: Colors.black,
                      fontSize: 20,
                      fontWeight: FontWeight.bold),
                ),
                TextButton(
                  onPressed: _logout,
                  child: Text(
                    "Log Out",
                    style: TextStyle(
                        color: Colors.red, fontWeight: FontWeight.bold),
                  ),
                ),
              ],
            )
                : Column(
              children: [
                TextButton(
                  onPressed: _login,
                  child: Text(
                    "Login",
                    style: TextStyle(
                        color: Colors.green, fontWeight: FontWeight.bold),
                  ),
                ),
                TextButton(
                  onPressed: _signup,
                  child: Text(
                    "Sign Up",
                    style: TextStyle(
                        color: Colors.blue, fontWeight: FontWeight.bold),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}



class AboutAppPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('About This App'),
      ),
      body: Center(
        child: Container(
          padding: EdgeInsets.all(20.0),
          child: Text('Habit Tracker is a cutting-edge habit tracker designed to empower'
          'users to build and maintain positive habits effectively.'
          'Whether you are striving to improve your fitness routine, boost productivity,'
          'or enhance your overall well-being, HabitForge provides the tools'
          ' and motivation needed to achieve your goals.'),
        ),
      ),
    );
  }
}
